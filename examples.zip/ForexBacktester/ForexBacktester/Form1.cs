﻿using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;
using TightDbCSharp;
using TightDbCSharp.Extensions;

namespace ForexBacktester
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        const int Onelinesize = 34; //how many bytes one line consists of
        private const int LinesAtATime = 1024*1024/34; //how many lines do we read in from the source file in each go

        private const int LinesToRead = 1024*1024;//number of lines we want to read. Set to a low number for debugging
        //usually bytes to read is onelinesize * linesAtATime, but the last chunck could be smaller
        //returns the last string processed for progress reporting purposes
         private string SourceDataToTightDb(byte[] sourcedata,int bytesToRead,Table tickTable)
         {
            string onelineutf16 = "";
            long position = 0;
            var oneline = new byte[Onelinesize];
            while (position < bytesToRead)
            {
                for (long n = 0; n < Onelinesize; n++)
                {
                    oneline[n] = sourcedata[n + position];
                }
                 position = position + Onelinesize;
                //Move data in oneline to some variables, throw them into the tightdb database
                //get the date                
                 onelineutf16 = Encoding.UTF8.GetString(oneline, 0, 34);
                DateTime dateTime = DateTime.ParseExact(onelineutf16.Substring(0,18), "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                double bid = Double.Parse(onelineutf16.Substring(19, 8), CultureInfo.InvariantCulture);
                double ask = Double.Parse(onelineutf16.Substring(19+8+1, 8), CultureInfo.InvariantCulture);
                tickTable.Add(dateTime, bid, ask, null);
            }
             return onelineutf16;
         }

        //
        private void Selectfile()
        {
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                string file = openFileDialog1.FileName;
                labelFileNameLoaded.Text = file;
                labelOperation.Text = "Opening File";
                Application.DoEvents();
            }            
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Selectfile();

            if (!File.Exists(labelFileNameLoaded.Text))
            {
                return;
            }
            
            //create a database named the same as the file we import

            FileInfo f = new FileInfo(labelFileNameLoaded.Text);

            var dbFileName = f.Name + ".tightdb";//.txt.tightdb.. fixup

            Group g = new Group(dbFileName);

            g.CreateTable("TICKS", "date".TightDbDate(), "Bid".Int(), "Ask".Int(),"systemresults".Table("SystemID".Int(),"SystemNAV".Double()));

            //Read the file into a similarily named tightdb database
            var sourceData = new byte[Onelinesize*LinesAtATime];
            var filesize = new FileInfo(labelFileNameLoaded.Text).Length;

            progressBar1.Maximum = (int) (filesize/(LinesAtATime*Onelinesize)) + 1;

            long totalbytesread = 0;
            var totalLinesRead = 0;
            int bytesread = 1;
            var fs = new FileStream(labelFileNameLoaded.Text, FileMode.Open, FileAccess.Read, FileShare.Read,
                Onelinesize*LinesAtATime);
            labelOperation.Text = "Processing Tick File";
            while (bytesread > 0 && totalLinesRead < LinesToRead)
            {
                bytesread = fs.Read(sourceData, 0, Onelinesize*LinesAtATime);
                if (bytesread > 0)
                {
                    totalbytesread += bytesread;
                    totalLinesRead = (int)(totalbytesread / Onelinesize);
                    labelProgress.Text = SourceDataToTightDb(sourceData, bytesread,g.GetTable("TICKS"));
                    progressBar1.Value++;
                    labelTotalBytesRead.Text = String.Format(CultureInfo.InvariantCulture, "{0,20}", totalbytesread);
                    labelTotalLinesRead.Text = String.Format(CultureInfo.InvariantCulture, "{0,20}", totalLinesRead);
                    Application.DoEvents();
                }
            }
        }

        //create a new empty database for tick data
        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


    }
}
