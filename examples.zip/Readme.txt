This archive contains a pre-setup running solution that uses tightdb.

1) unpack archive anywhere on your computer

2) open TutorialSolution\TutorialSolution.sln with VS2012 Express (or larger version)

3) click start to run the program, or hit F11 to step into the code and follow along
