This archive contains an already set up and running solution that uses tightdb.

1) unpack archive anywhere on your computer

2) open TutorialSolution\TutorialSolution.sln with VS2012 Express (or newer version)

3) click start to run the program, or hit F11 to step into the code and follow along

Other solutions might optionally be included in the archive. They work the same way.

The tightdb .net binding has been preinstalled in the lib directory and the projects are set up to work with it out of the box.
The tightdb dll files have been preinstalled into the directories where the project executables are located.
